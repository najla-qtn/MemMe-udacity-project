//
//  DetailMemeViewController.swift
//  myImageImporter
//
//  Created by Najla Al qahtani on 12/2/18.
//  Copyright © 2018 MAGNUMIUM. All rights reserved.
//

import UIKit

class DetailMemeViewController: UIViewController {
    @IBOutlet weak var imgView: UIImageView!
    
    var meme: Meme!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgView.image = meme.memedImage
    }
    
    @IBAction func editAction(_ sender: Any) {
        let detailController = storyboard!.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        detailController.sentMeme = self.meme
        self.navigationController?.pushViewController(detailController, animated: true)
    }
}
