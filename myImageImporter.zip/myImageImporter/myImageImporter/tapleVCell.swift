//
//  tapleVCell.swift
//  myImageImporter
//
//  Created by Najla Al qahtani on 12/2/18.
//  Copyright © 2018 MAGNUMIUM. All rights reserved.
//

import UIKit

class tapleVCell: UITableViewCell {
    @IBOutlet weak var memedImage: UIImageView!
    @IBOutlet weak var memedText: UILabel!
}

