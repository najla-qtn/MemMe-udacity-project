//
//  ViewController.swift
//  myImageImporter
//
//  Created by Sebastian Hette on 21.09.2016.
//  Copyright © 2016 MAGNUMIUM. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    let txtChanges = textDelegate()
   
    
    let textAttributes: [String : Any] = [
        NSFontAttributeName : UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
        NSStrokeWidthAttributeName : -3.0,//Shpuld be in minus
        NSForegroundColorAttributeName : UIColor.white,
        NSStrokeColorAttributeName : UIColor.black
        ]
    
    var sentMeme: Meme?
    @IBOutlet weak var share: UIBarButtonItem!
    @IBOutlet weak var navr: UINavigationBar!
    @IBOutlet weak var toolBar: UIToolbar!
    @IBOutlet weak var bottom: UITextField!
    @IBOutlet weak var top: UITextField!
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var myImageView: UIImageView!
    
    @IBAction func pickAnImageFromAlbum(_ sender: AnyObject)
    {
   
    /*اذا اختار زر الالبوم جيب له الصورة منها*/
         pickAnImage(sourceType: UIImagePickerController.SourceType.photoLibrary)
    }
    @IBAction func pickAnImageFromCamera(_ sender: Any) {
        /*اذا اختار له زر الكاميرا جيب له الصورة منها*/

        pickAnImage(sourceType: UIImagePickerController.SourceType.camera)
        share.isEnabled=true
        
    }
    
    func pickAnImage(sourceType: UIImagePickerController.SourceType) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = sourceType
        present(imagePicker, animated: true, completion: nil)
    }
    
    @IBAction func share(_ sender: Any) {
        let memedImage = generateMemedImage()
        let activityController = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
        activityController.completionWithItemsHandler = { activity, success, items, error in
            self.save()
            self.dismiss(animated: true, completion: nil)
        }
        
        present(activityController, animated: true, completion: nil)
        
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {  /*اذا قدر يوصل لليورل حق الامج بيسوي له كاستنتق بعدين ست لمتغير الامج الفيو*/
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage
        {
            myImageView.image = image
        }
        
        dismiss(animated: true, completion: nil)
        share.isEnabled=true
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        picker.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        /*إذا الكاميرا ما يمديني أوصل لها عطل الزر*/
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
       
        
    }
    func generateMemedImage() -> UIImage {
        
        // TODO: Hide toolbar and navbar
        navr.isHidden=true
        toolBar.isHidden=true
        // Render view to an image
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        // TODO: Show toolbar and navbar
        navr.isHidden=false
        toolBar.isHidden=false
        return memedImage
    }
    
    func save() {
  
        let meme = Meme(top: top.text! ,bottom: bottom.text! ,image: myImageView.image!, memedImage:  generateMemedImage())
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.memes.append(meme)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        share.isEnabled=false
        

        self.configureMemeTextField(textField: top, text: "TOP")
        self.configureMemeTextField(textField: bottom, text: "BOTTOM")
        
        // Do any additional setup after loading the view, typically from a nib.
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    func configureMemeTextField(textField: UITextField, text: String) {
        textField.text = text
        textField.adjustsFontSizeToFitWidth=true
        textField.delegate = txtChanges
        textField.defaultTextAttributes = textAttributes
        textField.textAlignment = .center
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        /*استدعاء ميثود الطرح هنا*/
        super.viewWillAppear(animated)
        subscribeToKeyboardNotification()
     
    }
    
    override func viewWillDisappear(_ animated: Bool) {
/*الغاء الطرح هنا*/
        super.viewWillDisappear(animated)
        print("here to end")
        
        if let memeDetail = sentMeme as Meme! {
            myImageView.image = memeDetail.image
        }
        
       unsubscribeToKeyboardNotification()

    }

    /*الميثودات الجاية هدفها ترفع الفيو لفوق عشان الكيبورد ما يغطي على التكست*/
    //When the keyboardWillShow notification is received, shift the view's frame up
    
    @objc func keyboardWillShow(_ notification: Notification){
        if bottom.isFirstResponder{
        view.frame.origin.y -= getKeyboardHeight(notification)
        }
        
    }
    @objc func keyboardWillHide(_ notification: Notification){
        view.frame.origin.y = 0
      
    }
    func getKeyboardHeight(_ notification: Notification) -> CGFloat{
    
      let userInfo=notification.userInfo
        let keyboredSize=userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue

        return keyboredSize.cgRectValue.height
       
    }
    func subscribeToKeyboardNotification(){
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
         NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)

    }
    
    func unsubscribeToKeyboardNotification(){
        
     NotificationCenter.default.removeObserver(self,   name: .UIKeyboardWillHide, object: nil)
       
    }

}

