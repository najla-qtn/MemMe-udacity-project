//
//  collectionVCell.swift
//  myImageImporter
//
//  Created by Najla Al qahtani on 12/2/18.
//  Copyright © 2018 MAGNUMIUM. All rights reserved.
//

import UIKit

class collectionVCell: UICollectionViewCell {

    @IBOutlet weak var imgMemed: UIImageView!
}
