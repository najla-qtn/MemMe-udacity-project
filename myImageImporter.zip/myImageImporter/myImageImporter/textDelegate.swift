//
//  textDelegate.swift
//  myImageImporter
//
//  Created by Najla Al qahtani on 11/15/18.
//  Copyright © 2018 MAGNUMIUM. All rights reserved.
//
import Foundation
import UIKit

class textDelegate: NSObject, UITextFieldDelegate {
    var active: UITextField!
    func textFieldDidBeginEditing(_ textField: UITextField) {
        active = textField
        textField.text = ""
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true;
    }
}
