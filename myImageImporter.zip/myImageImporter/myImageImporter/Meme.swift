//
//  Meme.swift
//  myImageImporter
//
//  Created by Najla Al qahtani on 12/1/18.
//  Copyright © 2018 MAGNUMIUM. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    var top: String
    var bottom: String
    var image: UIImage?
    var memedImage: UIImage?
}
